package edu.umkc.ericsson.model;

public class ServiceCall {
	
	
	
}
